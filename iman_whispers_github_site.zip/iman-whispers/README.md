# Iman Whispers — Static Website

This is a lightweight, mobile-friendly static website for Iman Whispers.

## Included
- Quran reading and recitation links
- Hadith collection links with a referenced example
- Daily dua section
- Islamic bookstore links
- Instagram, Facebook, YouTube, Pinterest and WhatsApp links

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository named `iman-whispers`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. GitHub will provide the public website URL after deployment.

## Important
The bookstore currently links to the Dar-us-Salam main store, not tracked affiliate product links. Replace those destinations with your exact affiliate URLs before promoting products. Quran and Hadith resources open established external services; this site does not host audio files or reproduce complete collections.
